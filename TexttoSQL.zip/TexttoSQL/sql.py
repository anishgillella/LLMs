import sqlite3

#Connect to sqllite
connection = sqlite3.connect("student.db")

# Create a cursor to insert record, create table, retrieve
cursor = connection.cursor()

#Create the table
table_delete = """

DELETE TABLE IF ALREADY EXISTS STUDENT;
"""
table_create = """
Create table if not exists STUDENT (NAME VARCHAR(25),CLASS VARCHAR(25), SECTION VARCHAR(25), MARKS INT);
"""
cursor.execute(table_delete)
cursor.execute(table_create)

#Insert some records
cursor.execute('''Insert Into STUDENT values('Krish','Data Science','A',90)''')
cursor.execute('''Insert Into STUDENT values('Sudhanshu','Data Science','B',100)''')
cursor.execute('''Insert Into STUDENT values('Darius','Data Science','A',86)''')
cursor.execute('''Insert Into STUDENT values('Vikash','DEVOPS','A',50)''')
cursor.execute('''Insert Into STUDENT values('Dipesh','DEVOPS','A',35)''')
cursor.execute('''Insert Into STUDENT values('Riya','Machine Learning','A',92)''')
cursor.execute('''Insert Into STUDENT values('Sandeep','Cyber Security','B',95)''')
cursor.execute('''Insert Into STUDENT values('Prateek','Artificial Intelligence','A',88)''')
cursor.execute('''Insert Into STUDENT values('Alok','Cloud Computing','A',55)''')
cursor.execute('''Insert Into STUDENT values('Akshay','Software Engineering','A',40)''')

cursor.execute('''Insert Into STUDENT values('Shreya','Information Technology','B',85)''')
cursor.execute('''Insert Into STUDENT values('Surya','Digital Marketing','C',72)''')
cursor.execute('''Insert Into STUDENT values('Rahul','Business Analytics','A',94)''')
cursor.execute('''Insert Into STUDENT values('Priya','Computer Science','B',60)''')
cursor.execute('''Insert Into STUDENT values('Neha','Blockchain Technology','A',45)''')

cursor.execute('''Insert Into STUDENT values('Rakesh','Machine Learning','A',90)''')
cursor.execute('''Insert Into STUDENT values('Sonal','Cyber Security','B',97)''')
cursor.execute('''Insert Into STUDENT values('Shivam','Artificial Intelligence','A',89)''')
cursor.execute('''Insert Into STUDENT values('Pooja','Cloud Computing','A',52)''')
cursor.execute('''Insert Into STUDENT values('Abhishek','Software Engineering','A',38)''')

cursor.execute('''Insert Into STUDENT values('Meera','Information Technology','B',82)''')
cursor.execute('''Insert Into STUDENT values('Manoj','Digital Marketing','C',70)''')
cursor.execute('''Insert Into STUDENT values('Nikita','Business Analytics','A',93)''')
cursor.execute('''Insert Into STUDENT values('Kiran','Computer Science','B',65)''')
cursor.execute('''Insert Into STUDENT values('Divya','Blockchain Technology','A',48)''')

cursor.execute('''Insert Into STUDENT values('Vishal','Machine Learning','A',91)''')
cursor.execute('''Insert Into STUDENT values('Raj','Cyber Security','B',96)''')
cursor.execute('''Insert Into STUDENT values('Sanjay','Artificial Intelligence','A',87)''')
cursor.execute('''Insert Into STUDENT values('Anjali','Cloud Computing','A',54)''')
cursor.execute('''Insert Into STUDENT values('Rohan','Software Engineering','A',42)''')

cursor.execute('''Insert Into STUDENT values('Komal','Information Technology','B',83)''')
cursor.execute('''Insert Into STUDENT values('Ankit','Digital Marketing','C',75)''')
cursor.execute('''Insert Into STUDENT values('Jyoti','Business Analytics','A',95)''')
cursor.execute('''Insert Into STUDENT values('Akash','Computer Science','B',62)''')
cursor.execute('''Insert Into STUDENT values('Harsh','Blockchain Technology','A',47)''')

cursor.execute('''Insert Into STUDENT values('Nisha','Machine Learning','A',89)''')
cursor.execute('''Insert Into STUDENT values('Ajay','Cyber Security','B',98)''')
cursor.execute('''Insert Into STUDENT values('Preeti','Artificial Intelligence','A',86)''')
cursor.execute('''Insert Into STUDENT values('Ritu','Cloud Computing','A',58)''')
cursor.execute('''Insert Into STUDENT values('Amit','Software Engineering','A',36)''')

cursor.execute('''Insert Into STUDENT values('Vikram','Information Technology','B',80)''')
cursor.execute('''Insert Into STUDENT values('Anu','Digital Marketing','C',73)''')
cursor.execute('''Insert Into STUDENT values('Manisha','Business Analytics','A',92)''')
cursor.execute('''Insert Into STUDENT values('Rajesh','Computer Science','B',68)''')
cursor.execute('''Insert Into STUDENT values('Anurag','Blockchain Technology','A',49)''')

cursor.execute('''Insert Into STUDENT values('Isha','Machine Learning','A',88)''')
cursor.execute('''Insert Into STUDENT values('Aryan','Cyber Security','B',99)''')
cursor.execute('''Insert Into STUDENT values('Geeta','Artificial Intelligence','A',85)''')
cursor.execute('''Insert Into STUDENT values('Pavan','Cloud Computing','A',53)''')
cursor.execute('''Insert Into STUDENT values('Varun','Software Engineering','A',39)''')



#Display records
print("The inserted records are ")

data = cursor.execute("""SELECT * FROM STUDENT""")
for row in data:
    print(row)

#To complete all the operations, we need to close the connection
connection.commit()
connection.close()
